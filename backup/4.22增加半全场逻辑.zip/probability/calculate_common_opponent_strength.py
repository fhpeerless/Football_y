import json
import os
import sys
import math
from datetime import datetime
from collections import defaultdict

def get_project_root():
    script_dir = os.path.dirname(os.path.abspath(__file__))
    return os.path.dirname(script_dir)

try:
    from extract_common_opponent_matches import get_current_period
except ImportError:
    print("警告: 无法导入 extract_common_opponent_matches 模块")
    print("请确保 extract_common_opponent_matches.py 在同一目录下")
    def get_current_period():
        try:
            project_root = get_project_root()
            present_file = os.path.join(project_root, 'present.json')
            with open(present_file, 'r', encoding='utf-8') as f:
                present_data = json.load(f)
            if not present_data or not isinstance(present_data, list) or len(present_data) == 0:
                return None
            last_record = present_data[-1]
            period = last_record.get('period')
            return str(period) if period else None
        except:
            return None

def load_extracted_data(file_path):
    try:
        with open(file_path, 'r', encoding='utf-8') as f:
            data = json.load(f)
        return data
    except Exception as e:
        print(f"加载共同对手比赛数据错误: {e}")
        return None

def poisson_prob(lam, k):
    if lam <= 0:
        return 1.0 if k == 0 else 0.0
    if k < 0:
        return 0.0
    try:
        log_p = -lam + k * math.log(lam) - math.lgamma(k + 1)
        return math.exp(log_p)
    except (ValueError, OverflowError):
        return 0.0

def calculate_win_draw_lose(lambda_home, lambda_away, max_goals=7):
    home_win = 0.0
    draw = 0.0
    away_win = 0.0
    for i in range(max_goals + 1):
        p_home = poisson_prob(lambda_home, i)
        for j in range(max_goals + 1):
            p = p_home * poisson_prob(lambda_away, j)
            if i > j:
                home_win += p
            elif i == j:
                draw += p
            else:
                away_win += p
    return home_win, draw, away_win

def parse_date(date_str):
    if not date_str:
        return None
    try:
        s = date_str.split(' ')[0] if ' ' in date_str else date_str
        return datetime.strptime(s, "%Y-%m-%d")
    except:
        return None

def time_decay_weight(match_date_str, current_date, half_life_days=180):
    match_date = parse_date(match_date_str)
    if match_date is None:
        return 0.1
    if isinstance(current_date, str):
        current_dt = parse_date(current_date)
        if current_dt is None:
            current_dt = datetime.now()
    else:
        current_dt = current_date
    days_diff = (current_dt - match_date).days
    if days_diff < 0:
        days_diff = 0
    
    tier = days_diff // 75
    weight = 1.0 - tier * 0.1
    return max(weight, 0.1)

def extract_team_match_stats(match, team_name):
    home_team = match.get('homesxname', '')
    away_team = match.get('awaysxname', '')
    home_score = match.get('homescore', 0)
    away_score = match.get('awayscore', 0)
    if home_team == team_name:
        return home_score, away_score, True
    elif away_team == team_name:
        return away_score, home_score, False
    return None, None, None

def calculate_poisson_from_common_opponents(common_data, home_team, away_team, current_date):
    HOME_ADVANTAGE = 1.10
    DIRECT_MATCH_WEIGHT_MULT = 2.0

    home_scored_w = 0.0
    home_conceded_w = 0.0
    home_weight_total = 0.0
    home_match_count = 0

    away_scored_w = 0.0
    away_conceded_w = 0.0
    away_weight_total = 0.0
    away_match_count = 0

    direct_match_count = 0
    opponent_details = []

    for opponent_key, matches_data in common_data.items():
        is_direct = matches_data.get('_is_direct_match', False)
        home_vs_opp = matches_data.get('home_vs_opponent', [])
        away_vs_opp = matches_data.get('away_vs_opponent', [])

        opp_h_scored = 0.0
        opp_h_conceded = 0.0
        opp_h_weight = 0.0
        opp_a_scored = 0.0
        opp_a_conceded = 0.0
        opp_a_weight = 0.0

        for match in home_vs_opp:
            scored, conceded, is_home = extract_team_match_stats(match, home_team)
            if scored is None:
                continue
            match_date = match.get('matchdate', '')
            w = time_decay_weight(match_date, current_date)
            if is_direct:
                w *= DIRECT_MATCH_WEIGHT_MULT
                direct_match_count += 1
            opp_h_scored += scored * w
            opp_h_conceded += conceded * w
            opp_h_weight += w
            home_match_count += 1

        for match in away_vs_opp:
            scored, conceded, is_home = extract_team_match_stats(match, away_team)
            if scored is None:
                continue
            match_date = match.get('matchdate', '')
            w = time_decay_weight(match_date, current_date)
            if is_direct:
                w *= DIRECT_MATCH_WEIGHT_MULT
            opp_a_scored += scored * w
            opp_a_conceded += conceded * w
            opp_a_weight += w
            away_match_count += 1

        home_scored_w += opp_h_scored
        home_conceded_w += opp_h_conceded
        home_weight_total += opp_h_weight
        away_scored_w += opp_a_scored
        away_conceded_w += opp_a_conceded
        away_weight_total += opp_a_weight

        opponent_details.append({
            '对手': opponent_key,
            '是否直接对战': is_direct,
            '主队对该对手进球加权': round(opp_h_scored, 3),
            '主队对该对手失球加权': round(opp_h_conceded, 3),
            '主队权重和': round(opp_h_weight, 3),
            '客队对该对手进球加权': round(opp_a_scored, 3),
            '客队对该对手失球加权': round(opp_a_conceded, 3),
            '客队权重和': round(opp_a_weight, 3)
        })

    home_attack = home_scored_w / home_weight_total if home_weight_total > 0 else 1.0
    home_defense = home_conceded_w / home_weight_total if home_weight_total > 0 else 1.0
    away_attack = away_scored_w / away_weight_total if away_weight_total > 0 else 1.0
    away_defense = away_conceded_w / away_weight_total if away_weight_total > 0 else 1.0

    lambda_home = (home_attack + away_defense) / 2.0 * HOME_ADVANTAGE
    lambda_away = (away_attack + home_defense) / 2.0

    home_win_prob, draw_prob, away_win_prob = calculate_win_draw_lose(lambda_home, lambda_away)

    DRAW_BOOST_MAX = 0.15
    max_lambda = max(lambda_home, lambda_away, 0.01)
    closeness = 1 - abs(lambda_home - lambda_away) / max_lambda
    draw_boost = closeness * DRAW_BOOST_MAX

    if home_win_prob + away_win_prob > 0:
        home_transfer = home_win_prob * draw_boost
        away_transfer = away_win_prob * draw_boost
        draw_prob += home_transfer + away_transfer
        home_win_prob -= home_transfer
        away_win_prob -= away_transfer

    probs = {'胜': home_win_prob, '平': draw_prob, '负': away_win_prob}
    max_result = max(probs, key=probs.get)
    result_map = {'胜': 3, '平': 1, '负': 0}

    calculation_details = {
        '计算方法': '共同对手泊松模型（分段加权+平局提升）',
        '主队攻击力(场均进球)': round(home_attack, 3),
        '主队防守力(场均失球)': round(home_defense, 3),
        '客队攻击力(场均进球)': round(away_attack, 3),
        '客队防守力(场均失球)': round(away_defense, 3),
        '主场优势系数': HOME_ADVANTAGE,
        '直接对战权重倍数': DIRECT_MATCH_WEIGHT_MULT,
        '实力接近度': round(closeness, 4),
        '平局概率提升': round(draw_boost, 4),
        '主队预期进球(lambda_home)': round(lambda_home, 3),
        '客队预期进球(lambda_away)': round(lambda_away, 3),
        '主队比赛样本数': home_match_count,
        '客队比赛样本数': away_match_count,
        '直接对战样本数': direct_match_count,
        '对手详情': opponent_details
    }

    return {
        '主队预期进球': round(lambda_home, 3),
        '客队预期进球': round(lambda_away, 3),
        '胜概率': round(home_win_prob, 4),
        '平概率': round(draw_prob, 4),
        '负概率': round(away_win_prob, 4),
        '预测结果': result_map[max_result],
        '主队攻击力': round(home_attack, 3),
        '主队防守力': round(home_defense, 3),
        '客队攻击力': round(away_attack, 3),
        '客队防守力': round(away_defense, 3),
        '详细计算数据': calculation_details
    }

def process_extracted_data(data, current_date):
    results = []
    matches_data = data.get('14场比赛共同对手比赛数据', {})
    if not matches_data:
        print("错误: 未找到比赛数据")
        return results

    print(f"开始处理 {len(matches_data)} 场比赛...")

    for match_num, match_data in matches_data.items():
        meta = match_data.get('_meta', {})
        home_team = meta.get('主队', '')
        away_team = meta.get('客队', '')
        match_date = meta.get('比赛时间', '')
        league = meta.get('联赛', '')
        home_rank = meta.get('主队排名', '')
        away_rank = meta.get('客队排名', '')

        if not home_team or not away_team:
            print(f"第{match_num}场比赛缺少主队或客队信息")
            continue

        print(f"\n处理第 {match_num} 场比赛")
        print(f"  联赛: {league}")
        print(f"  主队: {home_team} (排名: {home_rank})")
        print(f"  客队: {away_team} (排名: {away_rank})")

        common_data = {k: v for k, v in match_data.items() if k != '_meta'}

        if not common_data:
            print(f"  没有共同对手比赛数据")
            result = {
                '场次': match_num,
                '联赛': league,
                '主队': home_team,
                '主队排名': home_rank,
                '客队': away_team,
                '客队排名': away_rank,
                '比赛时间': match_date,
                '计算基准日期': current_date,
                '共同对手数': 0,
                '主队预期进球': 0,
                '客队预期进球': 0,
                '胜概率': 0,
                '平概率': 0,
                '负概率': 0,
                '预测结果': None,
                '主队攻击力': 0,
                '主队防守力': 0,
                '客队攻击力': 0,
                '客队防守力': 0,
                '错误': '没有共同对手比赛数据'
            }
            results.append(result)
            continue

        print(f"  找到共同对手: {len(common_data)} 个")

        poisson_result = calculate_poisson_from_common_opponents(
            common_data, home_team, away_team, current_date
        )

        print(f"  主队预期进球: {poisson_result['主队预期进球']:.3f}")
        print(f"  客队预期进球: {poisson_result['客队预期进球']:.3f}")
        print(f"  胜概率: {poisson_result['胜概率']:.1%}")
        print(f"  平概率: {poisson_result['平概率']:.1%}")
        print(f"  负概率: {poisson_result['负概率']:.1%}")
        print(f"  预测结果: {poisson_result['预测结果']}")

        result = {
            '场次': match_num,
            '联赛': league,
            '主队': home_team,
            '主队排名': home_rank,
            '客队': away_team,
            '客队排名': away_rank,
            '比赛时间': match_date,
            '计算基准日期': current_date,
            '共同对手数': len(common_data),
            '主队预期进球': poisson_result['主队预期进球'],
            '客队预期进球': poisson_result['客队预期进球'],
            '胜概率': poisson_result['胜概率'],
            '平概率': poisson_result['平概率'],
            '负概率': poisson_result['负概率'],
            '预测结果': poisson_result['预测结果'],
            '主队攻击力': poisson_result['主队攻击力'],
            '主队防守力': poisson_result['主队防守力'],
            '客队攻击力': poisson_result['客队攻击力'],
            '客队防守力': poisson_result['客队防守力'],
            '详细计算数据': poisson_result['详细计算数据']
        }
        results.append(result)

    return results

def main():
    project_root = get_project_root()
    result_dir = os.path.join(project_root, "result")
    os.makedirs(result_dir, exist_ok=True)

    period = get_current_period()
    if not period:
        print("错误: 无法从present.json获取当前期数")
        print("请检查present.json文件是否存在且格式正确")
        exit(1)

    print(f"使用当前在售期数: {period}期")
    input_file = os.path.join(result_dir, f"{period}期_共同对手比赛.json")
    output_file = os.path.join(result_dir, f"{period}期_共同对手实力分.json")

    if not os.path.exists(input_file):
        print(f"错误: 输入文件 {input_file} 不存在")
        print("请先运行 extract_common_opponent_matches.py 生成共同对手比赛数据")
        exit(1)

    print(f"输入文件: {input_file}")
    print(f"输出文件: {output_file}")
    print(f"期数: {period}期")

    data = load_extracted_data(input_file)
    if not data:
        print("加载共同对手比赛数据失败")
        exit(1)

    current_date = datetime.now().strftime("%Y-%m-%d")
    print(f"计算基准日期: {current_date}")

    print(f"\n开始处理 {data.get('期数', '')} 的 {len(data.get('14场比赛共同对手比赛数据', {}))} 场比赛...")
    print("=" * 80)

    results = process_extracted_data(data, current_date)

    output_data = {
        '期数': data.get('期数', ''),
        '计算基准日期': current_date,
        '计算方法': '共同对手泊松模型（时间衰减加权，主场优势修正）',
        '计算公式': 'lambda_home = (主队攻击力 + 客队防守力) / 2 × 主场优势系数; lambda_away = (客队攻击力 + 主队防守力) / 2; P(胜/平/负) = Σ Poisson(lambda_home,i) × Poisson(lambda_away,j)',
        '计算规则': '基于共同对手比赛数据，时间衰减加权计算攻击力和防守力，泊松分布推导胜平负概率',
        '14场比赛结果': results
    }

    with open(output_file, 'w', encoding='utf-8') as f:
        json.dump(output_data, f, ensure_ascii=False, indent=2)

    print("\n" + "=" * 80)
    print(f"处理完成！结果已保存到: {output_file}")

    total_matches = len(results)
    matches_with_data = sum(1 for r in results if r.get('共同对手数', 0) > 0)
    matches_without_data = total_matches - matches_with_data

    print(f"\n统计信息:")
    print(f"  总比赛数: {total_matches}")
    print(f"  有共同对手的比赛: {matches_with_data}")
    print(f"  无共同对手的比赛: {matches_without_data}")

    result_counts = {3: 0, 1: 0, 0: 0, None: 0}
    for r in results:
        pred = r.get('预测结果')
        result_counts[pred] = result_counts.get(pred, 0) + 1
    print(f"  预测主胜(3): {result_counts.get(3, 0)} 场")
    print(f"  预测平(1): {result_counts.get(1, 0)} 场")
    print(f"  预测客胜(0): {result_counts.get(0, 0)} 场")
    print(f"  无数据: {result_counts.get(None, 0)} 场")

    print(f"\n前3场比赛结果:")
    for i, result in enumerate(results[:3]):
        if i >= 3:
            break
        print(f"  第{result['场次']}场: {result['主队']} vs {result['客队']}")
        print(f"    共同对手数: {result.get('共同对手数', 0)}")
        print(f"    主队预期进球: {result.get('主队预期进球', 0):.3f}")
        print(f"    客队预期进球: {result.get('客队预期进球', 0):.3f}")
        print(f"    胜概率: {result.get('胜概率', 0):.1%}")
        print(f"    平概率: {result.get('平概率', 0):.1%}")
        print(f"    负概率: {result.get('负概率', 0):.1%}")
        print(f"    预测结果: {result.get('预测结果', '无')}")
        print()

if __name__ == "__main__":
    main()
